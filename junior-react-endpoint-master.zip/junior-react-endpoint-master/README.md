# GraphQL endpoint for Junior Developer position in Scandiweb

### Overview

You are going to need this endpoint in order to implement the assignment given to you (minimalistic storefront).

### How to start

In order to start this endpoint, follow these steps

1. Install dependencies
2. Build the project - `yarn build`
3. Start the project - `yarn start`

>**Note**: During the assignment, do not modify this endpoint. Also, no need to provide it along with your assessment.
